import 'package:flutter/material.dart';

//entry point
void main() {
  runApp(const MainApp());
}

//Widget (UI component)
//Stateless = not able to save data during run time
//Stateful = able to save data during run time
class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    //MaterialApp = a base of a mobile app
    return MaterialApp(
      //Scaffold = determines the dimension of an app
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Hello Flutter'),
          backgroundColor: Colors.blue,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            spacing: 5.0,
            children: [
              const Text("Login"),
              const TextField(
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  labelText: "Username",
                  border: OutlineInputBorder(),
                ),
              ),
              const TextField(
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                  labelText: "Password",
                  border: OutlineInputBorder(),
                ),
              ),
              ElevatedButton(
                onPressed: (){}, //Event handler (Empty)
                child: const Text("Login"),
              ),
              ElevatedButton(
                onPressed: (){},
                child: const Text("Register"),
              ),
            ],
          )
        ),
      ),
    );
  }
}
