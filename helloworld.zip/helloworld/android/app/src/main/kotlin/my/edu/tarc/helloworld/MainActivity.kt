package my.edu.tarc.helloworld

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
